#!usr/bin/env python
#coding=utf-8
import xlrd
import xlwt # 复杂格式无法处理
# https://www.cnblogs.com/python-robot/p/9958352.html
from xlutils.copy import copy
# https://www.jb51.net/article/60510.htm
# https://www.cnblogs.com/programmer-tlh/p/10461353.html
import os
# from openpyxl import load_workbook
# from openpyxl import worksheet, cell
# from openpyxl.styles import Font
# from copy import copy
# import time
import sys

def importdata(path):
    r = []
    rr = []
    with open(path, 'r') as f:
        for l in f:
            ln = l.rstrip().decode('gbk',errors='ignore')
            rr.append(ln)
    if len(rr) % 8 == 0:
        for i in range(len(rr)/8):
            print('import data...' + str(i) + '/' + str(len(rr)/8))
            doc = rr[i*8 + 1]
            kind = rr[i*8 + 2]
            str1 = rr[i*8 + 3]
            str2 = rr[i*8 + 4]
            str3 = rr[i*8 + 5]
            if kind == "TEXT":
                loc = rr[i*8 + 6].split(',')
                r.append({"doc": doc, "kind": kind, "str1": str1, "str2": str2, "str3": str3, "x": loc[0], "y": loc[1]})
            elif kind == "POLYLINE":
                vertex = []
                for v in rr[i*8 + 6].split('|'):
                    vertex.append(v.split(','))
                r.append({"doc": doc, "kind": kind, "vertex": vertex})
    return r

# def exportdata(path, data):
#     with open(path, 'w') as f:
#         for d in data:
#             if d["kind"] == 'TEXT':
#                 f.write('[\n')
#                 f.write(d["doc"] + '\n')
#                 f.write(d["kind"] + '\n')
#                 f.write(d["str1"] + '\n')
#                 f.write(d["str2"] + '\n')
#                 f.write(d["x"] + ',' + d["y"] + '\n')
#                 f.write(']\n')
#             elif d["kind"] == "POLYLINE":
#                 f.write('[\n')
#                 f.write(d["doc"] + '\n')
#                 f.write(d["kind"] + '\n')
#                 f.write("RESERVE\n")
#                 f.write("RESERVE\n")
#                 f.write(map(lambda v: v.join(','), d["vertex"]).join('|'))
#                 f.write(']\n')

def data2xls(path, data):
    print('read xls')
    if not os.path.exists(path):
        workbook = xlwt.Workbook(encoding = 'utf-8')
        worksheet = workbook.add_sheet('原理图变化差异和风险管控')
        worksheet.col(0).width = 2*250
        worksheet.col(1).width = 13*250
        worksheet.col(2).width = 9*250
        worksheet.col(3).width = 80*250
        worksheet.col(4).width = 40*250
        worksheet.col(5).width = 40*250
        worksheet.col(6).width = 10*250
        worksheet.col(7).width = 10*250
        worksheet.col(8).width = 20*250
        worksheet.col(9).width = 20*250
        worksheet.col(10).width = 20*250
        worksheet.col(10).width = 20*250

        worksheet.row(0).height = 2*200
        worksheet.row(1).height = 2*300
        worksheet.row(2).height = 2*290

        style = xlwt.XFStyle()
        font = xlwt.Font()
        font.name = u'微软雅黑' 
        font.bold = True
        font.height = 240
        font.colour_index = 8
        style.font = font
        alignment = xlwt.Alignment()
        alignment.horz = xlwt.Alignment.HORZ_CENTER
        alignment.vert = xlwt.Alignment.VERT_CENTER
        style.alignment = alignment
        borders= xlwt.Borders() # 为样式创建边框
        borders.top= xlwt.Borders.MEDIUM
        style.borders = borders
        worksheet.write_merge(1, 1, 1, 6, '文件编号：SY-SP01-HW-SOP01/WI01-02-F01', style)
        worksheet.write(1, 7, '', style)
        worksheet.write(1, 8, '', style)
        worksheet.write(1, 9, '', style)
        worksheet.write(1, 10, u'日期', style)
        style.num_format_str = u'yyyy"年"m"月"d"日"' 
        worksheet.write(1, 11, xlwt.Formula('TODAY()'), style)

        style = xlwt.XFStyle()
        font = xlwt.Font()
        font.name = u'微软雅黑' 
        font.bold = True
        font.height = 360
        font.colour_index = 8
        style.font = font
        alignment = xlwt.Alignment()
        alignment.horz = xlwt.Alignment.HORZ_CENTER
        alignment.vert = xlwt.Alignment.VERT_CENTER
        style.alignment = alignment
        borders= xlwt.Borders() # 为样式创建边框
        borders.top= xlwt.Borders.THIN
        style.borders = borders
        worksheet.write_merge(2, 2, 1, 11, '原理图变化差异记录', style)

        style = xlwt.XFStyle()
        font = xlwt.Font()
        font.name = u'微软雅黑' 
        font.bold = True
        font.height = 240
        font.colour_index = 8
        style.font = font
        alignment = xlwt.Alignment()
        alignment.horz = xlwt.Alignment.HORZ_CENTER
        alignment.vert = xlwt.Alignment.VERT_CENTER
        style.alignment = alignment
        borders= xlwt.Borders() # 为样式创建边框
        borders.top= xlwt.Borders.MEDIUM
        style.borders = borders
        worksheet.write_merge(3, 3, 1, 2, '前置板卡:', style)
        worksheet.write(3, 3, 'TP.XXX.XXX AXXX', style)
        worksheet.write(3, 4, '产品型号', style)
        worksheet.write(3, 5, '', style)
        worksheet.write(3, 6, '', style)
        worksheet.write(3, 7, '', style)
        worksheet.write(3, 8, '', style)
        worksheet.write(3, 9, '', style)
        worksheet.write_merge(3, 3, 10, 11, 'TP.XXX.XXX AXXX', style)

        style = xlwt.XFStyle()
        font = xlwt.Font()
        font.name = u'微软雅黑' 
        font.bold = True
        font.height = 240
        font.colour_index = 8
        style.font = font
        alignment = xlwt.Alignment()
        alignment.horz = xlwt.Alignment.HORZ_CENTER
        alignment.vert = xlwt.Alignment.VERT_CENTER
        style.alignment = alignment
        borders= xlwt.Borders() # 为样式创建边框
        borders.top= xlwt.Borders.THIN
        style.borders = borders
        worksheet.write(4, 1, '', style)
        worksheet.write(4, 2, 'NUDD', style)
        worksheet.write(4, 3, '对比前置板卡的变化差异项记录（Alt+Enter换行）', style)
        worksheet.write(4, 4, '变更原因', style)
        worksheet.write(4, 5, '变更时间', style)
        worksheet.write(4, 6, '图纸页码', style)
        worksheet.write(4, 7, '变更原因分类', style)
        worksheet.write(4, 8, '风险预防对策', style)
        worksheet.write(4, 9, '是否影响改板', style)
        worksheet.write(4, 10, '是否已评审', style)
        worksheet.write(4, 11, '评审人', style)
        
        style1 = xlwt.XFStyle()
        font = xlwt.Font()
        font.name = u'微软雅黑' 
        font.bold = False
        font.height = 240
        font.colour_index = 8
        style1.font = font
        alignment = xlwt.Alignment()
        alignment.horz = xlwt.Alignment.HORZ_LEFT
        alignment.vert = xlwt.Alignment.VERT_CENTER
        style1.alignment = alignment
        borders= xlwt.Borders() # 为样式创建边框
        borders.top= xlwt.Borders.THIN
        style1.borders = borders

        style2 = xlwt.XFStyle()
        font = xlwt.Font()
        font.name = u'微软雅黑' 
        font.bold = False
        font.height = 240
        font.colour_index = 8
        style2.font = font
        alignment = xlwt.Alignment()
        alignment.horz = xlwt.Alignment.HORZ_CENTER
        alignment.vert = xlwt.Alignment.VERT_CENTER
        style2.alignment = alignment
        borders= xlwt.Borders() # 为样式创建边框
        borders.top= xlwt.Borders.THIN
        style2.borders = borders

        style3 = xlwt.XFStyle()
        font = xlwt.Font()
        font.name = u'微软雅黑' 
        font.bold = False
        font.height = 120
        font.colour_index = 8
        style3.font = font
        alignment = xlwt.Alignment()
        alignment.horz = xlwt.Alignment.HORZ_CENTER
        alignment.vert = xlwt.Alignment.VERT_CENTER
        style3.alignment = alignment
        borders= xlwt.Borders() # 为样式创建边框
        borders.top= xlwt.Borders.THIN
        style3.borders = borders

        text = filter(lambda d: d["kind"] == "TEXT", data)
        pos = 5
        for d in range(len(text)):
            worksheet.write(pos+d, 1, '' , style1)
            worksheet.write(pos+d, 2, '' , style1)
            worksheet.write(pos+d, 3, text[d]["str1"] , style1)
            worksheet.write(pos+d, 4, text[d]["str2"] , style2)
            worksheet.write(pos+d, 5, text[d]["str3"] , style3)
            worksheet.write(pos+d, 6, text[d]["doc"] , style3)
            worksheet.write(pos+d, 7, '' , style1)
            worksheet.write(pos+d, 8, '' , style1)
            worksheet.write(pos+d, 9, '' , style1)
            worksheet.write(pos+d, 10, '' , style1)
            worksheet.write(pos+d, 11, '' , style1)

        
        workbook.save(path)
    else:
        rxls = xlrd.open_workbook(path, formatting_info=True)
        wxls = copy(rxls)
        rsheet = rxls.sheet_by_name(u'原理图变化差异和风险管控')
        rowrange = rsheet.nrows
        lastline = -1

        for i in range(5, rowrange):
            rowcell = rsheet.row(i)
            if not (rowcell[2].value or rowcell[3].value or rowcell[4].value or rowcell[5].value or rowcell[6].value or rowcell[7].value or rowcell[8].value or rowcell[9].value or rowcell[10].value):
                if lastline == -1:
                    lastline = i
            else:
                lastline = -1
        if lastline == -1:
            lastline = rowrange

        wsheet = wxls.get_sheet(u'原理图变化差异和风险管控')
        pos = lastline

        text = filter(lambda d: d["kind"] == "TEXT", data)
        _data = []
        for t in text:
            _exist = False
            for i in range(5, rowrange):
                rowcell = rsheet.row(i)
                if rowcell[3].value == t["str1"] and rowcell[4].value == t["str2"]:
                    _exist = True
                    break
            if not _exist:
                _data.append(t)

        style1 = xlwt.XFStyle()
        font = xlwt.Font()
        font.name = u'微软雅黑' 
        font.bold = False
        font.height = 240
        font.colour_index = 8
        style1.font = font
        alignment = xlwt.Alignment()
        alignment.horz = xlwt.Alignment.HORZ_LEFT
        alignment.vert = xlwt.Alignment.VERT_CENTER
        style1.alignment = alignment
        borders= xlwt.Borders() # 为样式创建边框
        borders.top= xlwt.Borders.THIN
        style1.borders = borders

        style2 = xlwt.XFStyle()
        font = xlwt.Font()
        font.name = u'微软雅黑' 
        font.bold = False
        font.height = 240
        font.colour_index = 8
        style2.font = font
        alignment = xlwt.Alignment()
        alignment.horz = xlwt.Alignment.HORZ_CENTER
        alignment.vert = xlwt.Alignment.VERT_CENTER
        style2.alignment = alignment
        borders= xlwt.Borders() # 为样式创建边框
        borders.top= xlwt.Borders.THIN
        style2.borders = borders

        style3 = xlwt.XFStyle()
        font = xlwt.Font()
        font.name = u'微软雅黑' 
        font.bold = False
        font.height = 120
        font.colour_index = 8
        style3.font = font
        alignment = xlwt.Alignment()
        alignment.horz = xlwt.Alignment.HORZ_CENTER
        alignment.vert = xlwt.Alignment.VERT_CENTER
        style3.alignment = alignment
        borders= xlwt.Borders() # 为样式创建边框
        borders.top= xlwt.Borders.THIN
        style3.borders = borders
        print('write xls')
        for t in range(len(_data)):
            print("write data " + str(t))
            wsheet.write(pos, 1, '' , style1)
            wsheet.write(pos, 2, '' , style1)
            wsheet.write(pos, 3, _data[t]["str1"] , style1)
            wsheet.write(pos, 4, _data[t]["str2"] , style2)
            wsheet.write(pos, 5, _data[t]["str3"] , style3)
            wsheet.write(pos, 6, _data[t]["doc"] , style3)
            wsheet.write(pos, 7, '' , style2)
            wsheet.write(pos, 8, '' , style2)
            wsheet.write(pos, 9, '' , style2)
            wsheet.write(pos, 10, '' , style2)
            wsheet.write(pos, 11, '' , style2)

            pos += 1
        wxls.save(path)

# def data2xlsx(path, data):
#     print('read xlsx')
#     t0 = time.time()
#     wb = load_workbook(filename = path)
#     t1 = time.time()
#     print('read xlsx finish!...' + str(t1-t0))
#     offsetrow = 6
#     font = Font(u'微软雅黑',size = 12,color='000000')
#     # print(wb.sheetnames)
#     for shn in wb.sheetnames:
#         if u'原理图变化差异和风险管控' in shn:
#             sheet_ranges = wb[shn]
#             text = filter(lambda d: d["kind"] == "TEXT", data)
#             lastline = -1
#             print('find last line')
#             t0 = time.time()
#             for x in range(offsetrow, sheet_ranges.max_row+1):
#                 print('find last line...' + str(x) + '/' + str(sheet_ranges.max_row+1 - offsetrow))
#                 if lastline == -1 and sheet_ranges.cell(x, 3).value in [None, ''] and sheet_ranges.cell(x, 4).value in [None, ''] and sheet_ranges.cell(x, 5).value in [None, ''] and sheet_ranges.cell(x, 6).value in [None, ''] \
#                 and sheet_ranges.cell(x, 7).value in [None, ''] and sheet_ranges.cell(x, 8).value in [None, ''] and sheet_ranges.cell(x, 9).value in [None, ''] and sheet_ranges.cell(x, 10).value in [None, ''] and sheet_ranges.cell(x, 11).value in [None, '']:
#                     lastline = x
#                 elif lastline != -1 and (not sheet_ranges.cell(x, 3).value in [None, ''] or not sheet_ranges.cell(x, 4).value in [None, ''] or not sheet_ranges.cell(x, 5).value in [None, ''] or not sheet_ranges.cell(x, 6).value in [None, ''] \
#                 or not sheet_ranges.cell(x, 7).value in [None, ''] or not sheet_ranges.cell(x, 8).value in [None, ''] or not sheet_ranges.cell(x, 9).value in [None, ''] or not sheet_ranges.cell(x, 10).value in [None, ''] or not sheet_ranges.cell(x, 11).value in [None, '']):
#                     lastline = -1
#             t1 = time.time()
#             print('find last line finish!...' + str(t1-t0))
#             if lastline == -1:
#                 lastline = sheet_ranges.max_row
#                 for x in range(len(text)):
#                     sheet_ranges.insert_rows(lastline+1)
#             else:
#                 mrow = sheet_ranges.max_row
#                 for x in range(len(text) - sheet_ranges.max_row + lastline):
#                     sheet_ranges.insert_rows(mrow+1)
#             pos = 0
#             print('write data')
#             for d in range(len(text)):
#                 print('write data...' + str(x) + '/' + str(sheet_ranges.max_row+1 - offsetrow))
#                 _exist = False
#                 for x in range(offsetrow, sheet_ranges.max_row+1):
#                     if sheet_ranges.cell(x, 4).value == text[d]["str1"] and sheet_ranges.cell(x, 5).value == text[d]["str2"]:
#                         _exist = True
#                         break
#                 if _exist == False:
#                     pos += 1
#                     sheet_ranges.cell(lastline+pos, 4).value= text[d]["str1"] 
#                     sheet_ranges.cell(lastline+pos, 4).font = font
#                     sheet_ranges.cell(lastline+pos, 5).value = text[d]["str2"]
#                     sheet_ranges.cell(lastline+pos, 5).font = font
#                     sheet_ranges.cell(lastline+pos, 6).value = text[d]["str3"]
#                     sheet_ranges.cell(lastline+pos, 6).font = font
#                     sheet_ranges.cell(lastline+pos, 7).value = text[d]["doc"]
#                     sheet_ranges.cell(lastline+pos, 7).font = font
#             print('saving...')
#             t0 = time.time()
#             wb.save(filename = path)
#             t1 = time.time()
#             print('finish save!...' + str(t1-t0))

# def xlsx2data():
#     pass

if __name__ == "__main__":
    # data = importdata('schrecord.log')
    # data2xls('./text.xls', data)
    if len(sys.argv) == 3:
        print('begin')
        path = sys.argv[1]
        docstr = sys.argv[2]
        print(docstr)
        path2 = None
        (docpath, docname) = os.path.split(os.path.dirname(path))
        print(docpath)
        if docname == 'Documents':
            for p in os.listdir(docpath):
                # if docstr in p:
                #     path2 = docpath + '\\' + p
                if p == docstr + '.xls':
                    path2 = os.path.dirname(path) + '\\' + p
        if not path2:
            for p in os.listdir(os.path.dirname(path)):
                # if docstr in p:
                #     path2 = os.path.dirname(path) + '\\' + p
                if p == docstr + '.xls':
                    path2 = os.path.dirname(path) + '\\' + p
        if not path2:
            path2 = docpath + '\原理图变更记录.xls'.decode('utf-8').encode('gbk')
        print(path2)
        print('import data')
        data = importdata(path)
        print('export to xlsx')
        # data2xlsx(path2, data)
        data2xls(path2, data)
        print('finish!')
    else:
        print('param count error')
